# Zeta Zero Visualizer

This is a Dash-based web app that visualizes the non-trivial zeros of the Riemann Zeta function on the complex plane.

## Setup

1. Create a virtual environment (optional but recommended):
    python -m venv venv
    source venv/bin/activate  # or venv\Scripts\activate on Windows

2. Install dependencies:
    pip install -r requirements.txt

3. Run the app:
    python app.py

Then open your browser to http://127.0.0.1:8050/

Enjoy exploring the zeta zeros!