
import dash
from dash import dcc, html
import plotly.graph_objs as go
import numpy as np

app = dash.Dash(__name__)
server = app.server

# Generate values for complex plane
re = np.linspace(-20, 20, 800)
im = np.linspace(-20, 20, 800)
RE, IM = np.meshgrid(re, im)
Z = RE + 1j * IM

# Zeta function using mpmath
from mpmath import zeta
import mpmath
mpmath.mp.dps = 15

def zeta_abs(x, y):
    return abs(zeta(complex(x, y)))

# Generate known non-trivial zeros
# First 30 zeros from Riemann zeta function (approximated)
riemann_zeros = [
    14.134725, 21.022040, 25.010858, 30.424876, 32.935061,
    37.586178, 40.918719, 43.327073, 48.005150, 49.773832,
    52.970321, 56.446248, 59.347044, 60.831780, 65.112544,
    67.079811, 69.546402, 72.067158, 75.704690, 77.144840,
    79.337375, 82.910380, 84.735493, 87.425274, 88.809112,
    92.491899, 94.651345, 95.870634, 98.831194, 101.317852
]

# Layout
app.layout = html.Div([
    html.H1("Zeta Zero Visualizer"),
    dcc.Graph(
        id="zeta-zeros-plot",
        figure={
            "data": [
                go.Scatter(
                    x=[0.5]*len(riemann_zeros),
                    y=riemann_zeros,
                    mode='markers',
                    marker=dict(color='red', size=6),
                    name='Non-trivial Zeros (Re = 0.5)'
                )
            ],
            "layout": go.Layout(
                title="Non-trivial Zeros of the Riemann Zeta Function",
                xaxis=dict(title='Real Part'),
                yaxis=dict(title='Imaginary Part'),
                height=700
            )
        }
    )
])

if __name__ == "__main__":
    app.run_server(debug=True)
